# Southern Arm Control Description > urdf

This project holds the robot description files for the robots used by the workspace.

## Files
### andreas_arm_description.xacro
* This is the description for the Andreas Arm.
* Much of the code for this file is modified from the RViz and Gazebo tutorials.

### scorbot.xacro
* Much of the code for this file is modified from the RViz and Gazebo tutorials and from https://github.com/baijuchaudhari/sboter4u.git.
