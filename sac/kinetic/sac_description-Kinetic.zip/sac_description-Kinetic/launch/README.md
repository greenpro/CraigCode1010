# Southern Arm Control Description > launch

This folder holds the launch files for the package.

## Files
### gazebo.launch
* This file will launch Gazebo and load all of the publishers for the robot.
* Much of the code for this file is modified from the gazebo tutorial.
