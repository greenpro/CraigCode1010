# Southern Arm Control Translators > src > helpers

This folder holds any necessary include files for the translators.

## Files
### config.h
* This file holds all of the applicable global defines for the project.
