// System
#define RASPBERRY_PI

// Debug
#define DEBUG

// arm
//#define ANDREAS_ARM
#define SCORBOT
