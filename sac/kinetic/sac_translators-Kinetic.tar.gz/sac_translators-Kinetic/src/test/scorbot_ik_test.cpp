#include <gtest/gtest.h>

int main(int argc, cahr **argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
