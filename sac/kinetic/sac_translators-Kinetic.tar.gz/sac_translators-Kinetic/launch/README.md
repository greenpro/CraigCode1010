# Southern Arm Control Translators > launch

This folder holds all of the launch files for the project.

## Files
### translators.launch
* This file will launch all of the nodes for the system.
