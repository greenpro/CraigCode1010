# Southern Arm Control Setup > resources

This folder holds any resources which may be useful to the project.

## Files
### mastersDefense.pdf
* Paper written for the final defense of the project.

### mastersProposal.pdf
* Paper written for the initial proposal of the project.
