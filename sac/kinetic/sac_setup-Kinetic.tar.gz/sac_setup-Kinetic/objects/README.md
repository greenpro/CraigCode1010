# Southern Arm Control Setup > objects

This folder holds all of the mesh objects for the world. These objects will be moved to the .gazebo meshes folder in the home folder.

## Files
### tower0
* The base block for the Towers of Hanoi tower.

### tower1
* The lower middle block for the Towers of Hanoi tower.

### tower2
* The upper middle block for the Towers of Hanoi tower.

### tower3
* The optional top block for the Towers of Hanoi tower.
