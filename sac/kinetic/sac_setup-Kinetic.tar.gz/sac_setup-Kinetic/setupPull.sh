git pull

cp workspaceScripts/* ~/sac/
