cd ~/sac/src/sac_controllers
git pull

cd ~/sac/src/sac_description
git pull

cd ~/sac/src/sac_drivers
git pull

cd ~/sac/src/sac_gazebo
git pull

cd ~/sac/src/sac_translators
git pull

cd ~/sac/src/sac_launch
git pull

cd ~/sac/src/sac_msgs
git pull

cd ~/sac/src/sac_config
git pull

cd ~/sac/src/scorbot_config
git pull

cd ~/sac/src/andreas_arm_config
git pull

cd ~/sac

./build.sh
