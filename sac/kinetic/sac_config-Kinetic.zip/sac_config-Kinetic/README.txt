Purpose:
    - This package implements the drivers for the system to communicate with the hardware. Some of
      these nodes may communicate with the microcontroller driver to send messages to allow for
      serial communication.
--------------------------------------------------------------------------------------------------------------------------------------

Notes:
--------------------------------------------------------------------------------------------------------------------------------------

Reference:
    - The Items for the Scorbot-er III in this package have been modified from https://github.com/baijuchaudhari/sboter4u.git
    - The Items for the implementation of the Andreas Arm have been moved to config_andreas
