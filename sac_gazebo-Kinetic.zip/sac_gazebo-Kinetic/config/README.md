# Southern Arm Control Gazebo > config

This folder contains the mappings from the robot joints to their message ROS inputs.

## Files
### andreas_arm_control.yaml
* The mappings for the Andreas Arm.
* This code is modified from the tutorials for gazebo.

### scorbot_control.yaml
* The mappings for the Scorbot.
* This code is modified from the tutorials for gazebo.
