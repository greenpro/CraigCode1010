# Southern Arm Control Gazebo > worlds

This project holds the worlds for the arms in the project.

## Files
### andreas_arm.world
* This file holds the world for the andreas arm.

### scorbot.world
* This file holds the world for the scorbot.
