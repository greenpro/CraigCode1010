# Southern Arm Control Config

[Description of the project and what it contains]

## Installation

To install the Southern Arm Control system download sac_setup from https://github.com/greenpro/sac_setup.git and run the setup.sh script for Ubuntu or the rpiSetup.sh script for Raspian.

## Files
### [File0.Name]
* [Description item 1  ]
* [Description item ...]
* [Description item N  ]
* [Attribution]

### [File1.Name]
* [Description item 1  ]
* [Description item ...]
* [Description item N  ]
* [Attribution]

## Folders
### [Folder0Name/]
* [Contents of the folder]
* [Guidelines for the folder]

### [Folder1Name/]
* [Contents of the folder]
* [Guidelines for the folder]

## Remove
* [folders and files to look into removing at a later time]

## Notes
* [General Note 0]
* [General Note 1]
