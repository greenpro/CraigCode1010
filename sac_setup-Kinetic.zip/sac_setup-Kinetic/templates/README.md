# Southern Arm Control Setup > templates

This folder holds any file templates which may be useful to the project.

## Files
### README_mainTemplate.md
* This contains the template for the base folder of a package.
* The items in [] can be replaced to create the README.md file.

### README_subFolderTemplate.md
* This contains the template for the sub folders of a package.
* The items in [] can be replaced to create the README.md file.
