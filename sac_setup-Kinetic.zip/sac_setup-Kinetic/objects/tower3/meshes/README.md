# Southern Arm Control Setup > objects > tower3 > meshes

This folder holds all of the mesh objects for the world. These objects will be moved to the .gazebo/models folder in the home folder.

## Files
### tower0.dae
* Description for a box with feet for the top of the Towers of Hanoi.

## Notes
* .dae files and other 3d files can be easily modified by using the 3D Builder app in the current version of Windows 10.
