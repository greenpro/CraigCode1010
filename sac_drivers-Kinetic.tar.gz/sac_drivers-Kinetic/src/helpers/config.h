#ifndef CONFIG_H
#define CONFIG_H

// System
#define RASPBERRY_PI

// Debug
#define DEBUG

// arm
//#define ANDREAS_ARM
#define SCORBOT

#endif // CONFIG_H
